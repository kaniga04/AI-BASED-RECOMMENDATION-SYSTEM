package dhivya;

import java.util.*;

public class App {

    public static void main(String[] args) {
        // Sample dataset
        Map<String, List<String>> dataset = new HashMap<>();
        dataset.put("action", Arrays.asList("Mad Max", "John Wick", "The Dark Knight"));
        dataset.put("comedy", Arrays.asList("Superbad", "The Hangover", "Step Brothers"));
        dataset.put("drama", Arrays.asList("The Shawshank Redemption", "Forrest Gump", "The Godfather"));

        // User preference
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Recommendation System!");
        System.out.println("What type of movie do you like? (Action, Comedy, Drama)");
        String userPreference = scanner.nextLine().trim().toLowerCase(); // Normalize input

        // Get recommendations
        List<String> recommendations = dataset.getOrDefault(userPreference, Collections.emptyList());

        // Output recommendations
        if (recommendations.isEmpty()) {
            System.out.println("Sorry, no recommendations found for your preference.");
        } else {
            System.out.println("Here are some recommendations for " + userPreference + " movies:");
            for (String movie : recommendations) {
                System.out.println("- " + movie);
            }
        }

        scanner.close();
    }
}
